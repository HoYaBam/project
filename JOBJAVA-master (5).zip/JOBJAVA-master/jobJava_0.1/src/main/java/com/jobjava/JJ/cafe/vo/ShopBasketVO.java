package com.jobjava.JJ.cafe.vo;

public class ShopBasketVO {

	private int SHOP_NO;
	private int JOB_NO;
	private int EMP_NO;
	private String ID;

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public int getSHOP_NO() {
		return SHOP_NO;
	}

	public void setSHOP_NO(int sHOP_NO) {
		SHOP_NO = sHOP_NO;
	}

	public int getJOB_NO() {
		return JOB_NO;
	}

	public void setJOB_NO(int jOB_NO) {
		JOB_NO = jOB_NO;
	}

	public int getEMP_NO() {
		return EMP_NO;
	}

	public void setEMP_NO(int eMP_NO) {
		EMP_NO = eMP_NO;
	}

	
	
	
	
	

}
