package com.jobjava.JJ.counselor.vo;

public class AlarmVO { 
	private int EMP_PAR_NO;
	private String TITLE;
	private String AGENT;
	private String DIVISION;

	public int getEMP_PAR_NO() {
		return EMP_PAR_NO;
	}
	public void setEMP_PAR_NO(int eMP_PAR_NO) {
		EMP_PAR_NO = eMP_PAR_NO;
	}
	public String getTITLE() {
		return TITLE;
	}
	public void setTITLE(String tITLE) {
		TITLE = tITLE;
	}
	public String getAGENT() {
		return AGENT;
	}
	public void setAGENT(String aGENT) {
		AGENT = aGENT;
	}
	public String getDIVISION() {
		return DIVISION;
	}
	public void setDIVISION(String dIVISION) {
		DIVISION = dIVISION;
	}
	
}