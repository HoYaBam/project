package com.jobjava.JJ.cafe.vo;

public class EmpVO {

	private int EMP_NO;
	private String ID;
	private String NAME;
	private String RANK;

	public int getEMP_NO() {
		return EMP_NO;
	}

	public void setEMP_NO(int eMP_NO) {
		EMP_NO = eMP_NO;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getNAME() {
		return NAME;
	}

	public void setNAME(String nAME) {
		NAME = nAME;
	}

	public String getRANK() {
		return RANK;
	}

	public void setRANK(String rANK) {
		RANK = rANK;
	}

}
