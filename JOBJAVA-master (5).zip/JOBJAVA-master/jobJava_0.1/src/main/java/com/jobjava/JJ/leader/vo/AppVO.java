package com.jobjava.JJ.leader.vo;

public class AppVO {
	private int APP_NO;
	private String HOPE_JOB;
	private String APP_REASON;
	private String FILENAME;
	
	public int getAPP_NO() {
		return APP_NO;
	}
	public void setAPP_NO(int aPP_NO) {
		APP_NO = aPP_NO;
	}
	public String getHOPE_JOB() {
		return HOPE_JOB;
	}
	public void setHOPE_JOB(String hOPE_JOB) {
		HOPE_JOB = hOPE_JOB;
	}
	public String getAPP_REASON() {
		return APP_REASON;
	}
	public void setAPP_REASON(String aPP_REASON) {
		APP_REASON = aPP_REASON;
	}
	public String getFILENAME() {
		return FILENAME;
	}
	public void setFILENAME(String fILENAME) {
		FILENAME = fILENAME;
	}
	
}
