package com.jobjava.JJ.leader.vo;

import java.util.Date;

public class UniVO {
	private int UNI_B_NO;
	private String B_NAME;
	private String U_NAME;
	private String STATE;
	private Date S_DATE;
	private Date E_DATE;
	
	public int getUNI_B_NO() {
		return UNI_B_NO;
	}
	public void setUNI_B_NO(int uNI_B_NO) {
		UNI_B_NO = uNI_B_NO;
	}
	public String getB_NAME() {
		return B_NAME;
	}
	public void setB_NAME(String b_NAME) {
		B_NAME = b_NAME;
	}
	public String getU_NAME() {
		return U_NAME;
	}
	public void setU_NAME(String u_NAME) {
		U_NAME = u_NAME;
	}
	public String getSTATE() {
		return STATE;
	}
	public void setSTATE(String sTATE) {
		STATE = sTATE;
	}
	public Date getS_DATE() {
		return S_DATE;
	}
	public void setS_DATE(Date s_DATE) {
		S_DATE = s_DATE;
	}
	public Date getE_DATE() {
		return E_DATE;
	}
	public void setE_DATE(Date e_DATE) {
		E_DATE = e_DATE;
	}
	
}
