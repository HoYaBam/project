package com.jobjava.JJ.cafe.board;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.sql.Date;

public class ArticleVO {
	private int jobno;
	private String career;
	private String edu;
	private String area;
	private String sal;
	private String emptype;
	private String worktype;
	private String welfare;
	private String company;
	private String btype;
	private String scale;
	private Date establish;
	private String ysales;
	private String hp;
	private String empnum;
	private String sdate;
	private String ddate;
	private String jobd;
	

	
	
	

}
