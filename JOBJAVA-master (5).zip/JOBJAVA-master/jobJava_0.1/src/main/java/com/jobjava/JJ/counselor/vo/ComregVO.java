package com.jobjava.JJ.counselor.vo;

public class ComregVO {
	private String B_NO;
	private String ID;
	private String AGENT;
	private String B_TYPE;
	private String C_DIV;
	private int EMP_NUM;
	private String HOMEPAGE;
	private String C_NAME;
	private String EMAIL;
	private int CM_NO;
	
	
	public int getCM_NO() {
		return CM_NO;
	}
	public void setCM_NO(int cM_NO) {
		CM_NO = cM_NO;
	}
	public String getEMAIL() {
		return EMAIL;
	}
	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}
	public String getB_NO() {
		return B_NO;
	}
	public void setB_NO(String b_NO) {
		B_NO = b_NO;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getAGENT() {
		return AGENT;
	}
	public void setAGENT(String aGENT) {
		AGENT = aGENT;
	}
	public String getB_TYPE() {
		return B_TYPE;
	}
	public void setB_TYPE(String b_TYPE) {
		B_TYPE = b_TYPE;
	}
	public String getC_DIV() {
		return C_DIV;
	}
	public void setC_DIV(String c_DIV) {
		C_DIV = c_DIV;
	}
	public int getEMP_NUM() {
		return EMP_NUM;
	}
	public void setEMP_NUM(int eMP_NUM) {
		EMP_NUM = eMP_NUM;
	}
	public String getHOMEPAGE() {
		return HOMEPAGE;
	}
	public void setHOMEPAGE(String hOMEPAGE) {
		HOMEPAGE = hOMEPAGE;
	}
	public String getC_NAME() {
		return C_NAME;
	}
	public void setC_NAME(String c_NAME) {
		C_NAME = c_NAME;
	}
	
	

}
