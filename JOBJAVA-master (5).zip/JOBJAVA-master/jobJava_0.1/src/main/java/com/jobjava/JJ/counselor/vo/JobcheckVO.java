package com.jobjava.JJ.counselor.vo;

public class JobcheckVO {
	private String ID;
	private int CHECK_NO;
	private int APP_NO;
	private int SINCERITY;
	private int POSITIVENESS;
	private int CREATIVITY;
	private int PAR_RATE;
	private String CONTENT;
	
	public int getCHECK_NO() {
		return CHECK_NO;
	}
	public void setCHECK_NO(int cHECK_NO) {
		CHECK_NO = cHECK_NO;
	}
	public int getAPP_NO() {
		return APP_NO;
	}
	public void setAPP_NO(int aPP_NO) {
		APP_NO = aPP_NO;
	}
	public int getSINCERITY() {
		return SINCERITY;
	}
	public void setSINCERITY(int sINCERITY) {
		SINCERITY = sINCERITY;
	}
	public int getPOSITIVENESS() {
		return POSITIVENESS;
	}
	public void setPOSITIVENESS(int pOSITIVENESS) {
		POSITIVENESS = pOSITIVENESS;
	}
	public int getCREATIVITY() {
		return CREATIVITY;
	}
	public void setCREATIVITY(int cREATIVITY) {
		CREATIVITY = cREATIVITY;
	}
	public int getPAR_RATE() {
		return PAR_RATE;
	}
	public void setPAR_RATE(int pAR_RATE) {
		PAR_RATE = pAR_RATE;
	}
	public String getCONTENT() {
		return CONTENT;
	}
	public void setCONTENT(String cONTENT) {
		CONTENT = cONTENT;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}

}
