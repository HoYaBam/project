package com.jobjava.JJ.counselor.vo;

import java.sql.Date;

public class JobregVO {
	private int JOB_NO;
	private String CAREER;
	private String EDU;
	private String AREA;
	private String SAL;
	private String EMP_TYPE;
	private String WORK_TYPE;
	private String WELFARE;
	private String COMPANY;
	private String B_TYPE;
	private String SCALE;
	private Date ESTABLISH;
	private String Y_SALES;
	private String HP;
	private String EMP_NUM;
	private Date S_DATE;
	private Date D_DATE;
	private String JOB_D;
	private String TITLE;

	public String getTITLE() {
		return TITLE;
	}

	public void setTITLE(String tITLE) {
		TITLE = tITLE;
	}

	public int getJOB_NO() {
		return JOB_NO;
	}

	public void setJOB_NO(int jOB_NO) {
		JOB_NO = jOB_NO;
	}

	public String getCAREER() {
		return CAREER;
	}

	public void setCAREER(String cAREER) {
		CAREER = cAREER;
	}

	public String getEDU() {
		return EDU;
	}

	public void setEDU(String eDU) {
		EDU = eDU;
	}

	public String getAREA() {
		return AREA;
	}

	public void setAREA(String aREA) {
		AREA = aREA;
	}

	public String getSAL() {
		return SAL;
	}

	public void setSAL(String sAL) {
		SAL = sAL;
	}

	public String getEMP_TYPE() {
		return EMP_TYPE;
	}

	public void setEMP_TYPE(String eMP_TYPE) {
		EMP_TYPE = eMP_TYPE;
	}

	public String getWORK_TYPE() {
		return WORK_TYPE;
	}

	public void setWORK_TYPE(String wORK_TYPE) {
		WORK_TYPE = wORK_TYPE;
	}

	public String getWELFARE() {
		return WELFARE;
	}

	public void setWELFARE(String wELFARE) {
		WELFARE = wELFARE;
	}

	public String getCOMPANY() {
		return COMPANY;
	}

	public void setCOMPANY(String cOMPANY) {
		COMPANY = cOMPANY;
	}

	public String getB_TYPE() {
		return B_TYPE;
	}

	public void setB_TYPE(String b_TYPE) {
		B_TYPE = b_TYPE;
	}

	public String getSCALE() {
		return SCALE;
	}

	public void setSCALE(String sCALE) {
		SCALE = sCALE;
	}

	public Date getESTABLISH() {
		return ESTABLISH;
	}

	public void setESTABLISH(Date eSTABLISH) {
		ESTABLISH = eSTABLISH;
	}

	public String getY_SALES() {
		return Y_SALES;
	}

	public void setY_SALES(String y_SALES) {
		Y_SALES = y_SALES;
	}

	public String getHP() {
		return HP;
	}

	public void setHP(String hP) {
		HP = hP;
	}

	public String getEMP_NUM() {
		return EMP_NUM;
	}

	public void setEMP_NUM(String eMP_NUM) {
		EMP_NUM = eMP_NUM;
	}

	public Date getS_DATE() {
		return S_DATE;
	}

	public void setS_DATE(Date s_DATE) {
		S_DATE = s_DATE;
	}

	public Date getD_DATE() {
		return D_DATE;
	}

	public void setD_DATE(Date d_DATE) {
		D_DATE = d_DATE;
	}

	public String getJOB_D() {
		return JOB_D;
	}

	public void setJOB_D(String jOB_D) {
		JOB_D = jOB_D;
	}

}
