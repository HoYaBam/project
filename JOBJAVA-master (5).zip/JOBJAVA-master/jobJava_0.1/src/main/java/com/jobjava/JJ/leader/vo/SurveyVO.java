package com.jobjava.JJ.leader.vo;

public class SurveyVO {
	private int SV_NO;
	private int Q_NO;
	private String TITLE;
	private String S_DATE;
	private String E_DATE;
	private String Q_TXT;
	private String NAME;
	private String DIVISION;
	
	public int getSV_NO() {
		return SV_NO;
	}
	public void setSV_NO(int sV_NO) {
		SV_NO = sV_NO;
	}
	public int getQ_NO() {
		return Q_NO;
	}
	public void setQ_NO(int q_NO) {
		Q_NO = q_NO;
	}
	public String getTITLE() {
		return TITLE;
	}
	public void setTITLE(String tITLE) {
		TITLE = tITLE;
	}
	public String getS_DATE() {
		return S_DATE;
	}
	public void setS_DATE(String s_DATE) {
		S_DATE = s_DATE;
	}
	public String getE_DATE() {
		return E_DATE;
	}
	public void setE_DATE(String e_DATE) {
		E_DATE = e_DATE;
	}
	public String getQ_TXT() {
		return Q_TXT;
	}
	public void setQ_TXT(String q_TXT) {
		Q_TXT = q_TXT;
	}
	public String getNAME() {
		return NAME;
	}
	public void setNAME(String nAME) {
		NAME = nAME;
	}
	public String getDIVISION() {
		return DIVISION;
	}
	public void setDIVISION(String dIVISION) {
		DIVISION = dIVISION;
	}
	
}
