package com.jobjava.JJ.member.vo;

public class MMemberVO {
	private String ID;
	private String PWD;
	private String HP;
	private String ADDR;
	private String EMAIL;
	private String AUTHORITY;
	private boolean ENABLED;
	private int MG_NO;
	private String U_NAME;
	private String NAME;
	
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getPWD() {
		return PWD;
	}
	public void setPWD(String pWD) {
		PWD = pWD;
	}
	public String getHP() {
		return HP;
	}
	public void setHP(String hP) {
		HP = hP;
	}
	public String getADDR() {
		return ADDR;
	}
	public void setADDR(String aDDR) {
		ADDR = aDDR;
	}
	public String getEMAIL() {
		return EMAIL;
	}
	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}
	public String getAUTHORITY() {
		return AUTHORITY;
	}
	public void setAUTHORITY(String aUTHORITY) {
		AUTHORITY = aUTHORITY;
	}
	public boolean isENABLED() {
		return ENABLED;
	}
	public void setENABLED(boolean eNABLED) {
		ENABLED = eNABLED;
	}
	public int getMG_NO() {
		return MG_NO;
	}
	public void setMG_NO(int mG_NO) {
		MG_NO = mG_NO;
	}
	public String getU_NAME() {
		return U_NAME;
	}
	public void setU_NAME(String u_NAME) {
		U_NAME = u_NAME;
	}
	public String getNAME() {
		return NAME;
	}
	public void setNAME(String nAME) {
		NAME = nAME;
	}

}
