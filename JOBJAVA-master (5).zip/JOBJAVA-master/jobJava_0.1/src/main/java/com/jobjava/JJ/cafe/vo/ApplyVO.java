package com.jobjava.JJ.cafe.vo;

import java.sql.Date;

public class ApplyVO {
	private int EMP_PAR_NO;
	private int PROGRAM_NO;
	private String ID;
	private String QUESTION;
	
	public int getEMP_PAR_NO() {
		return EMP_PAR_NO;
	}
	public void setEMP_PAR_NO(int eMP_PAR_NO) {
		EMP_PAR_NO = eMP_PAR_NO;
	}
	public int getPROGRAM_NO() {
		return PROGRAM_NO;
	}
	public void setPROGRAM_NO(int pROGRAM_NO) {
		PROGRAM_NO = pROGRAM_NO;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getQUESTION() {
		return QUESTION;
	}
	public void setQUESTION(String qUESTION) {
		QUESTION = qUESTION;
	}

	

}
	
	
	